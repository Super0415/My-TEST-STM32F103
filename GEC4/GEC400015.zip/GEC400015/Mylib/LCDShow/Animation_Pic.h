#ifndef  ANIMATION_PIC_H
#define   ANIMATION_PIC_H

#include "TYPCortex.h"

extern GUI_CONST_STORAGE GUI_BITMAP bmclose;
extern const GUI_BITMAP bmMicriumLogo;
extern GUI_CONST_STORAGE GUI_BITMAP bmGen1;
extern GUI_CONST_STORAGE GUI_BITMAP bmFac1;
extern GUI_CONST_STORAGE GUI_BITMAP bmOilTP1;
extern GUI_CONST_STORAGE GUI_BITMAP bmspdlc;
extern GUI_CONST_STORAGE GUI_BITMAP bmopen;

#endif
